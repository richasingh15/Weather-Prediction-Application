import React from 'react';
import ReactDOM from 'react-dom';
import $ from 'jquery'; 
class WheatherForecast extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  setOutput = () => {
    let output = "<div>";
    let i = 0;
    while(i < 5) {
      let j = 0;
      let minTemp = 1000;
      let maxTemp = 0;
      
      output += "<br><br><span id='date"+ i +"'>Date: " + this.state.list[i*8].dt_txt.split(" ")[0] + "</span> <button class='date' id='"+ i +"'>View 3 Hourly Forecast</button><br>";
      while(j < 8) {
        if(minTemp > this.state.list[i*8+j].main.temp_min) {
          minTemp = this.state.list[i*8+j].main.temp_min
        }
        if(maxTemp < this.state.list[i*8+j].main.temp_max) {
          maxTemp = this.state.list[i*8+j].main.temp_max
        }
        output += "<div style='display:none;'class='" + i + "'>"
        output += "<span style='display:none; color: red;' class='"+ i +"'> Time:" + this.state.list[i*8+j].dt_txt.split(" ")[1] + "</span><br>";
        output += "<span style='display:none; color: red;' class='"+ i +"'> Minimum Temperature:" + this.state.list[i*8+j].main.temp_min + "</span><br>";
        output += "<span style='display:none; color: red;' class='"+ i +"'> Maximum Temperature:" + this.state.list[i*8+j].main.temp_max + "</span><br>";
        output += "</div>"
        j++;
      }
      output += "<span id='minTemp"+ i +"'>Minimum Temperature: " + minTemp + "</span><br>";
      output += "<span id='maxTemp"+ i +"'>Maximum Temperature: " + maxTemp + "</span><br>";
      switch(this.state.list[i*8].weather[0].main) {
        case "Clouds" :
          output += "<img src='https://png.pngtree.com/png-clipart/20190603/original/pngtree-cloud-png-image_314158.jpg' alt='" + this.state.list[i*8].weather[0].main + "' height='50' width='50'>";
          break;
        case "Rain" :
          output += "<img src='https://png.pngtree.com/png-clipart/20190517/original/pngtree-blue-cute-cartoon-clouds-and-raindrops-png-image_4140331.jpg' alt='" + this.state.list[i*8].weather[0].main + "' height='50' width='50'>";          
          break;
        case "Clear" :
          output += "<img src='https://png.pngtree.com/png-vector/20190826/ourlarge/pngtree-clear-sky-in-the-daytime-png-image_1699567.jpg' alt='" + this.state.list[i*8].weather[0].main + "' height='50' width='50'>";          
          break;
        case "Snow" :
          output += "<img src='https://png.pngtree.com/png-clipart/20190520/original/pngtree-the-third-design-the-light-grey-png-image_3726038.jpg' alt='" + this.state.list[i*8].weather[0].main + "' height='50' width='50'>";          
          break;
        case "Extreme" :
          output += "<img src='https://png.pngtree.com/png-vector/20191023/ourlarge/pngtree-hurricane-icon-flat-style-png-image_1845343.jpg' alt='" + this.state.list[i*8].weather[0].main + "' height='50' width='50'>";          
          break;
        default :
          output += "<span>" + this.state.list[i*8].weather[0].main + "</span>";
          break;
      }
      // output += "<img src='https://png.pngtree.com/png-clipart/20190603/original/pngtree-cloud-png-image_314158.jpg' alt='Clouds'>";
      // output += "<img id='image"+ i +"' src='" + require("'./images/" + this.state.list[i*8].weather[0].main + ".png'") + "' alt='" + this.state.list[i*8].weather[0].main + "' height='50' width='50'>";
      console.log(this.state.list[i*8].weather[0].main);
      i++;
    }
    output += "</div>";
    $('#output').empty().append(output);
    console.log($('.date').length)
    let k = 0;
    while(k < $('.date').length) {
      console.log($('.date')[k]);
      $('.date')[k].addEventListener('click', event => {
        let className = event.target.id;
        let classes = $("."+className);
        let l = 0;
        while(l < classes.length) {
          $(classes[l]).toggle();
          l++;
        }
      });
      k++;
    }
  }
  submitHandler = (event) => {
    event.preventDefault();
    let city = $('#cityInput').val();
    let country = $('#countryInput').val();
    fetch('https://api.openweathermap.org/data/2.5/forecast?q='+ city +',' + country + '&units=metric&APPID=b421ae9f400c4c501ab4bb0cd28fbe90')
    .then(res => res.json())
    .then((result) => {
      if(result.cod === "404") {
        $('#output').empty().append("<h5>Please enter City and Country to get Weather Forecast</h5>")
      } else {
        this.setState(result); 
        this.setOutput();
        // $('.')
        console.log(result)     
      }
    })
  }
  render() {
    return (
      <div>
        <form onSubmit={this.submitHandler}>
          <h1>Weather Finder</h1>
          <h2>Find Weather Conditions all over the world</h2>
          <label>City:</label>
          <input type="text" id="cityInput" placeholder="Enter City" width="100" style={{marginLeft: "10px"}}/><br/><br/>
          <label>Country:</label>
          <input type="text" id="countryInput" placeholder="Enter Country" width="100" style={{marginLeft: "10px"}}/><br/><br/>
          <input type="submit" value="Get Forecast"/>
        </form>
        <div id="output"></div>
      </div>
    );
  }
}
ReactDOM.render(<WheatherForecast />, document.getElementById('root'));